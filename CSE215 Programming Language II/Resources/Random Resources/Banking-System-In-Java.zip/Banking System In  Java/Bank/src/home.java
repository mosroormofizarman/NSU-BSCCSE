import javax.swing.*;
public class home extends javax.swing.JFrame 
{
    String name,acc_type;
    int Acc_num,Acc_Balance;
    JOptionPane JOptionPane1;
    public home() 
    {
        initComponents();
    }
     void create_account(String n,int acc_num,int b,String a_t)
    {
        name=n;
        Acc_num=acc_num;
        Acc_Balance=b;
        acc_type=a_t;
    }
     void deposit(int acct, int deposit)
     {
         Acc_num = acct;
         Acc_Balance = deposit;   
     }
     int Accnum()
     { 
      return Acc_num;   
     }  
void display()
{ 
    System.out.println(this.name);
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        create = new javax.swing.JButton();
        deposit = new javax.swing.JButton();
        withdraw = new javax.swing.JButton();
        check = new javax.swing.JButton();
        display = new javax.swing.JButton();
        Apply = new javax.swing.JButton();
        open = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        create.setText("Create Account");
        create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createActionPerformed(evt);
            }
        });

        deposit.setText("Deposit Money");
        deposit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                depositActionPerformed(evt);
            }
        });

        withdraw.setText("Withdraw Money");
        withdraw.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                withdrawActionPerformed(evt);
            }
        });

        check.setText("Check Balance");
        check.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkActionPerformed(evt);
            }
        });

        display.setText("Display Account Details");
        display.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayActionPerformed(evt);
            }
        });

        Apply.setText("Apply for loan");
        Apply.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ApplyActionPerformed(evt);
            }
        });

        open.setText("Open Fix Deposit Account");
        open.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Desktop\\banklog(1).jpg")); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(create, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(withdraw, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(381, 381, 381)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Apply)
                            .addComponent(check))
                        .addContainerGap(77, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(deposit)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(display)
                        .addGap(55, 55, 55))))
            .addGroup(layout.createSequentialGroup()
                .addGap(267, 267, 267)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(open))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(create, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(check))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(display)
                    .addComponent(deposit))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(open)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(withdraw)
                    .addComponent(Apply))
                .addGap(70, 70, 70))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void depositActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_depositActionPerformed
        // TODO add your handling code here:
        //deposit b = new deposit();
        //b.setVisible(true);
    //   new deposit().setVisible(true);
      //  this.setVisible(false);
         javax.swing.JTextField acctnum = new javax.swing.JTextField(15);
      javax.swing.JTextField amount = new javax.swing.JTextField(15);

       javax.swing.JPanel myPanel = new  javax.swing.JPanel();
      myPanel.add(new JLabel("Account Number"));
      myPanel.add(acctnum);
      myPanel.add(Box.createVerticalStrut(10)); // a spacer
      myPanel.add(new JLabel("Amount To Deposit"));
      myPanel.add(amount);

      int result = JOptionPane.showConfirmDialog(null, myPanel, 
               "Deposit Money", JOptionPane.OK_CANCEL_OPTION);
      if (result == JOptionPane.OK_OPTION) {
       int Acct = Integer.parseInt(acctnum.getText());
           int   deposits = Integer.parseInt(amount.getText());
           deposit(Acct,deposits);
           JOptionPane1.showMessageDialog(this,""+deposits+ " Has been succsessfully \n Deposited" );    
      }
      
      else
          JOptionPane1.showMessageDialog(this,"Kindly enter  Account Number and press OK"); 
        
    }//GEN-LAST:event_depositActionPerformed

    private void createActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createActionPerformed
        // TODO add your handling code here:
              // new createacc().setVisible(true);
              // this.setVisible(false);
        
         javax.swing.JTextField acctnam = new javax.swing.JTextField(15);
         
      javax.swing.JComboBox type = new javax.swing.JComboBox();
      type.addItem("select");
      type.addItem("savings");
      type.addItem("current");

       javax.swing.JPanel myPanel = new  javax.swing.JPanel();
      myPanel.add(new JLabel("Account Name"));
      myPanel.add(acctnam);
      myPanel.add(Box.createVerticalStrut(10)); // a spacer
      myPanel.add(new JLabel("Account Type"));
      myPanel.add(type);

      int result = JOptionPane.showConfirmDialog(null, myPanel, 
               "Create Account", JOptionPane.OK_CANCEL_OPTION);
      if (result == JOptionPane.OK_OPTION) {
       String Acct = acctnam.getText();
           String  deposit = type.getSelectedItem().toString();
           int bal=0;
            int acctnum =(int)((Math.random()*9000)+1000);
           create_account(Acct,acctnum,bal,deposit);
            JOptionPane1.showMessageDialog(this,"Account Created Succeffully \n Account Number : "+acctnum);
      }
      
      else
          JOptionPane1.showMessageDialog(this,"Kindly enter  Account Number and press OK");
        
    }//GEN-LAST:event_createActionPerformed

    private void displayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayActionPerformed
//accountd a = new accountd();
//String name = this.name;
//a.acct_details(name);
//a.setVisible(true);
//this.setVisible(false);
        
        javax.swing.JTextField acctnum = new javax.swing.JTextField(15);
     

       javax.swing.JPanel myPanel = new  javax.swing.JPanel();
      myPanel.add(new JLabel("Account Number"));
      myPanel.add(acctnum);
      myPanel.add(Box.createVerticalStrut(10)); // a spacer
 
      int result = JOptionPane.showConfirmDialog(null, myPanel, 
               "Please Enter Account Number ", JOptionPane.OK_CANCEL_OPTION);
      if (result == JOptionPane.OK_OPTION) {
       int Acct = Integer.parseInt(acctnum.getText());
         if(Acct== Acc_num)
           {
            
           JOptionPane1.showMessageDialog(this," Account Name: "+ name+"\n Account Number"+Acc_num+"\nAccount Type"+acc_type+"\nAccount  Balance ="+Acc_Balance );
           }
           else
          JOptionPane1.showMessageDialog(this,"Account Number Not Valid");
        
        // TODO add your handling code here:
    }//GEN-LAST:event_displayActionPerformed
    }
    private void withdrawActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_withdrawActionPerformed
//new withdraw().setVisible(true);
//this.setVisible(false);
// TODO add your handling code here:
        
        
                 javax.swing.JTextField acctnum = new javax.swing.JTextField(15);
      javax.swing.JTextField amount = new javax.swing.JTextField(15);

       javax.swing.JPanel myPanel = new  javax.swing.JPanel();
      myPanel.add(new JLabel("Account Number"));
      myPanel.add(acctnum);
      myPanel.add(Box.createVerticalStrut(10)); // a spacer
      myPanel.add(new JLabel("Amount To Withdraw"));
      myPanel.add(amount);

      int result = JOptionPane.showConfirmDialog(null, myPanel, 
               "Enter Acct and the Amount to withdraw", JOptionPane.OK_CANCEL_OPTION);
      if (result == JOptionPane.OK_OPTION) {
       int Acct = Integer.parseInt(acctnum.getText());
           int   deposits = Integer.parseInt(amount.getText());
           if(Acct== Acc_num)
           {
               if(deposits<Acc_Balance)
               {
                    Acc_Balance = Acc_Balance - deposits;
               
               
                        JOptionPane1.showMessageDialog(this,""+ deposits+ " Has been withdrawn \n Balance ="+Acc_Balance );
                   
               }
               
               else
                      JOptionPane1.showMessageDialog(this,"Amount to be withdrwan must be less than Available \n Your Availabale is:"+Acc_Balance);
                   
   
           }
               
             else
          JOptionPane1.showMessageDialog(this,"Account Number Not Valid");
        
      }
      
      else
          JOptionPane1.showMessageDialog(this,"Kindly enter  Account Number and press OK");

    }//GEN-LAST:event_withdrawActionPerformed

    private void checkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkActionPerformed
//new check().setVisible(true);
//this.setVisible(false);
        // TODO add your handling code here:
          javax.swing.JTextField acctnum = new javax.swing.JTextField(15);
     

       javax.swing.JPanel myPanel = new  javax.swing.JPanel();
      myPanel.add(new JLabel("Account Number"));
      myPanel.add(acctnum);
      myPanel.add(Box.createVerticalStrut(10)); // a spacer
 
      int result = JOptionPane.showConfirmDialog(null, myPanel, 
               "Please Enter Account Number ", JOptionPane.OK_CANCEL_OPTION);
      if (result == JOptionPane.OK_OPTION) {
       int Acct = Integer.parseInt(acctnum.getText());
           
           if(Acct==this.Acc_num)
           {
                 JOptionPane1.showMessageDialog(this,"Account Balance is:"+Acc_Balance);
           }
            
      else
          JOptionPane1.showMessageDialog(this,"Kindly enter  Account Number and press OK");
        
      }
     
        
        
    }//GEN-LAST:event_checkActionPerformed

    private void ApplyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ApplyActionPerformed

       loans l = new loans(Acc_num,Acc_Balance);
       l.setVisible(true);
        
        
      //  new loan().setVisible(true);
      //  this.setVisible(false);
                // TODO add your handling code here:
    }//GEN-LAST:event_ApplyActionPerformed

    private void openActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openActionPerformed
        // TODO add your handling code here:
        
        fixdepo d = new fixdepo();
       d.setVisible(true);
    }//GEN-LAST:event_openActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               home h = new home();
h.setVisible(true);
                
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Apply;
    private javax.swing.JButton check;
    private javax.swing.JButton create;
    private javax.swing.JButton deposit;
    private javax.swing.JButton display;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton open;
    private javax.swing.JButton withdraw;
    // End of variables declaration//GEN-END:variables
}
