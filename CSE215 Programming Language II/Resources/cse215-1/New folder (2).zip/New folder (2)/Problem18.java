import java.util.*;
import java.lang.*;
import java.io.*;
class Problem18{
public static void main(String[] args){
Scanner input =new Scanner(System.in);
System.out.print("Enter a point with two coordinate:");
double a=input.nextDouble();
double b=input.nextDouble();
System.out.println();
int rlength;
rlength=5;
double rwidth;
rwidth=5.0/2;
if(a<=rlength && b<=rwidth){
System.out.println("point("+a+","+b+") is in the rectangle");
}
else{
System.out.println("point("+a+","+b+") is not in the rectangle");
}
}
}
