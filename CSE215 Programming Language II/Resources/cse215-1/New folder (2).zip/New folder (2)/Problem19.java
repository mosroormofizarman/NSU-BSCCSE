import java.util.*;
import java.lang.*;
import java.io.*;
class Problem19{
public static void main(String[] args){
Scanner input=new Scanner(System.in);
System.out.print("Scissor(0) ,rock(1),paper(2):");
int num=input.nextInt();
switch(num){
case 0:
System.out.print("You are Scissor");
break;
case 1:
System.out.print("You are rock");
break;
case 2:
System.out.print("You are paper");
break;
default:
System.out.print("you entered wrong number:");
break;
}
System.out.print(" ");
int com=(int)(Math.random()*3);
switch(com){
case 0:
System.out.print("Computer is scissor");
break;
case 1:
System.out.print("Computer is rock");
break;
case 2:
System.out.print("Computer is paper");
break;
}
System.out.print(" ");
int i;
int scissor=0;
int rock=1;
int paper=2;
if (com==scissor && num==rock){
System.out.println("you win");
}
else if (com==scissor && num==paper){
System.out.println("you lose");
}
else if (com==scissor && num==scissor){
System.out.println("It is a draw");
}
else if (com==rock && num==rock){
System.out.println("it is a draw");
}
else if (com==rock && num==paper){
System.out.println("you win");
}
else if (com==rock && num==scissor){
System.out.println("you lose");
}
else if (com==paper && num==rock){
System.out.println("you lose");
}
else if (com==paper && num==paper){
System.out.println("it is a draw");
}
else if (com==paper && num==scissor){
System.out.println("you win");
}
}
}

