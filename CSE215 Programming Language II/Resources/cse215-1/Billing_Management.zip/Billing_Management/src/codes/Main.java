package codes;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
public class Main {

	public static void main(String[] args) {		
		
		SetUpApp sua= new SetUpApp();
		sua.showWindow();
		
	}

}
