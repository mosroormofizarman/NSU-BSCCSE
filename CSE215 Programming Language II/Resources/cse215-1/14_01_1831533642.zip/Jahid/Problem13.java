import java.util.*;
import java.lang.*;
import java.io.*;

public class problem13 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("input invest amnt: ");
		double amount = input.nextDouble();
		
		System.out.print("input annual interst: ");
		double minterest = input.nextDouble();
		minterestrate = minterets/1200;
		
		System.out.print("Enter  years: ");
		int years = input.nextInt();

		double finvestValue = amount * Math.pow(1 + minterestRate, years * 12);
		
		// Display result
		System.out.println("cal value is $" + finvestValue);
	}
}