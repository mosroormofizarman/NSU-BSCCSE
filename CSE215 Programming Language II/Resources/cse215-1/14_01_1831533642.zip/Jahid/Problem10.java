import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem10 {

	public static void main(String[] arg) {
	
		Scanner input = new Scanner(System.in);

		System.out.print("input driving dis: ")
		double dis = input.nextDouble();
		
		System.out.print("input miles per gallon: ");
		double miles_Per_Gallon = input.nextDouble()
		
		System.out.print("input price per gallon: ");
		double price_Per_Gallon = input.nextDouble();

		double costOf_Driving = (dis/ miles_Per_Gallon) * price_Per_Gallon;

		System.out.println("cost of driving is $" + costOf_Driving);
	}
}