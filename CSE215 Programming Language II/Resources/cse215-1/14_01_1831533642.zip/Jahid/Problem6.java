import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem6 {
	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);

		System.out.print("enter subtotal and gratuity rate: ")
		double subtotal = input.nextDouble();
		double gratuityRate = input.nextDouble();

		double gratuity = subtotal * (gratuityRate / 100);
		double total = subtotal + gratuity;

		System.out.println("The gratuity $" + gratuity + " and total $" + total);
	}
}