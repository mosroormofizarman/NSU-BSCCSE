import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem17{
    public static void main(String[] args){

        Scanner input = new Scanner(System.in);

        System.out.print("input three nbrs: ");
        int input = input.nextInt();

        int temp = 0;

        int d1 = input% 10;
        temp_remaning =input / 10;
        int d2 = temp% 10;
        int d3 = temp/ 10;

        String revs = Integer.toString(d3) + Integer.toString(d2) + Integer.toString(d1);
        String orgnal = Integer.toString(input);
        

        if(revs.equals(orgnal)){
            System.out.println(orgnal + " is a palindrone");
        }else{
            System.out.println(orgnal + " is not a palindrone");

        }
    }
}