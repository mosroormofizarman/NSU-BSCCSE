import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem3 {
         
    double kilomtr,miles,miles_hour;
    public static void main(String[] args) {
        
        kilomtrs = 14.0;
        miles = kilomtrs / 1.6;

        hour = (45.5 * 60.0 + 30.0) / (60.0 * 60.0);
        miles_Hour = miles / hour;

        System.out.println(miles_Hour);


    }
s
}