import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem16{
    public static void main(String[] args)
	{

        Scanner in = new Scanner(System.in);

        System.out.printf("input todays date: ");
        int date = in.nextInt();
		
        System.out.print("input nbr of days: ");
        int abir = in.nextInt();

        int future_date = (date + abir) % 7;
        String day_of_week = "";

        switch(date){
            case 0: dayofweek = "Sunday";
                    break;
            case 1: dayofweek = "Monday";
                    break; 
            case 2: dayofweek = "Tuesday";
                    break;
            case 3: dayofweek= "Wednesday";
                    break;
            case 4: dayofweek = "Thursday";
                   break;
            case 5:dayofweek = "Friday";
                    break;
            case 6:dayofweek = "Saturday";
                    break;
        }

        if (future_date == 0){
            System.out.printf("Todays is %s and the future day is Sunday", dayofweek);
        }else if(future_date == 1){
            System.out.printf("Todays is %s and the future day is Monday",dayofweek);
        }else if(future_date == 2){
            System.out.printf("Todays is %s and the future day is Tuesday",dayofweek);
        }else if(future_date == 3){
            System.out.printf("Todays is %s and the future day is Wednesday",dayofweek);
        }else if(future_date == 4){
            System.out.printf("Todays is %s and the future day is Thursday",dayofweek);
        }else if(future_date == 5){
            System.out.printf("Todays is %s and the future day is Friday",dayofweek);
        }else if(future_date == 6){
            System.out.printf("todays is %s and the future day is Saturday",dayofweek);
        }
    }
}