import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem14 
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);

		int d1 = (int)(Math.random() * 10);
		int d2 = (int)(Math.random() * 10);
		int d3 = (int)(Math.random() * 10);
         
		int sum=0;
		sum=System.out.println("it is " + d1 + " + " + d2 + " + " + d3 );
		int ans = input.nextInt();
		System.out.println("ans is :+ans );
		
		if(ans==sum)
		{
		 System.out.println("you are right");
		}
		else
		     System.out.println("you are wrong");
		    
	}
}