import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem7 {
	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);
		
		System.out.print("input nbr of minutes: ")
		int minutes = input.nextInt();
		
		int years = minutes / 525600;
		int days = (minutes % 525600) / 1440;

		System.out.println(minutes + " minutes is approximately " + years + " years and " + days + " days");
	}
}