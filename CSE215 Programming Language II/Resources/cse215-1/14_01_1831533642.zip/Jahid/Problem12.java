import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem12
{

    public static void main(String[] args)
	{
	
	system.out.println("a\t" + "b\t" + "pow(a,b)");
	int i;
	for(i=1,j=i+1;i<=5;i++)
	{
	System.out.println(i\t + j=i+1\t + (int)(Math.pow(a,b)));
	}
    }
}