import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem19 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		int computer = (int)(Math.random() * 3);

		System.out.print("scissor (0),rock (1),paper (2): ");
		int user = input.nextInt();

		System.out.print("computer is ");
		switch (computer)
		{
			case 0: System.out.print("scissor.");
			break;
			case 1: System.out.print("rock.");
			break;
			case 2: System.out.print("paper.");
			break;
		}

		System.out.print(" you r ");
		switch (user)
		{
			case 0: System.out.print("scissor");
			break;
			case 1: System.out.print("rock");
			break;
			case 2: System.out.print("paper ");
			break;
		}

		if (computer == user)
			System.out.println(" you draws");
		else
		{
			win = (user == 0 && computer == 2) ||(user == 1 && computer == 0)||(user == 2 && computer == 1);
			if (win)
				System.out.println("You wins");
			else
				System.out.println("You loses");
		}
	}
}