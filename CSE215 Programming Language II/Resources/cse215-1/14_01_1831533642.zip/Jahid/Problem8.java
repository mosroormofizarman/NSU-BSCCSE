import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem8 {

	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);
		
		 double KILOGRAMS_POUND = 0.45359237
		 double METERS_INCH = 0.0254;

		System.out.print("input weight in pnds: ");
		double weight = input.nextDouble();

		System.out.print("input height in incs: ");
		double height = input.nextDouble();

		weight = weight *KILOGRAMS_POUND
		height = height * METERS_INCH;

		double BMI = weight / Math.pow(height, 2);

		System.out.println("BMI is " + BMI);
	}
}