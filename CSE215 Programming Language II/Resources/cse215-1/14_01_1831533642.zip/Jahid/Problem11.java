import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem11 {
	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);

		System.out.print("Enter number betwn 0 and 1000: ");
		int number = input.nextInt();

		int lessthan10 = number % 10;
		number = number/10;
		int ntens = number % 10;
		number = number/10;
		int nhundreds = number % 10;
		number = number/10;
		int sum = nhundreds + ntens + lessthan10;	

		System.out.println("The sum is " + sum);
	}
}