import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem4 {

    public static void main(String[] strings) {

        double birthRateIn_Seconds = 7.0;
        double deathRateIn_Seconds = 13.0;
        double newImmigrantIn_Seconds = 45.0;



        double current_Ptn = 312032486;

        double secondsIn_Years = 60 * 60 * 24 * 365;

        double num_Births = secondsIn_Years / birthRateIn_Seconds;
        double num_Deaths = secondsIn_Years / deathRateIn_Seconds;
        double num_Immigrants = secondsIn_Years / newImmigrantIn_Seconds;

        for (int i = 1; i <= 5; i++) {
            current_Ptn += num_Births + num_Immigrants - num_Deaths;
            System.out.println("Year " + i + " = " + (int)current_Population);

        }


    }
}