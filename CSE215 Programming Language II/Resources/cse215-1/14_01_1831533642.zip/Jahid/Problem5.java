import java.util.Scanner;
import java.lang.*;
import java.io.*;

public class Problem5 {

    double cls,fheit;
	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);
		
		System.out.print("input in cls: ");
		 cls = input.nextDouble();

		 fheit = 9.0 / 5 * cls + 32;

		System.out.println(cls + " cls is " + fheit+ " Fheit is"); 
	}
}