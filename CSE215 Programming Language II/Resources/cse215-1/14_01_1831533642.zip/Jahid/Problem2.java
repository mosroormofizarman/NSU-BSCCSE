import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem2 {
 
   double rad = 5.5;

   public static void main(String[] args){

        double perimtr = 2 * Math.PI * rad;
        double area = Math.PI * rad * rad;

        System.out.println("Perimtr is = " + perimtr);
        System.out.println("Area is = " + area);
   }
}