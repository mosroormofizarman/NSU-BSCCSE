   import java.util.*;
   import java.lang.*;
   import java.io.*;

    public class Problem15
	{
	   public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.print("input three integers: ");
		int nbr1 = input.nextInt();
		int nbr2 = input.nextInt();
		int nbr3 = input.nextInt();

		int temp;
		if (nbr2 < nbr1 ||nbr3 < nbr1)
		{
			if (nbr2 <nbr1)
			{
				temp = v1;
				nbr1 =nbr2;
				nbr2 = temp; 
			}
			if (nbr3 < nbr1)
			{
				temp =nbr1;
				nbr1 = nbr3;
				nbr3 = temp;
			}
		}
		if (nbr3 < nbr2)
		{
			temp = nbr2;
			nbr2 = nbr3;
			nbr3 = temp;
		}

		System.out.println(nbr1 + " " + nbr2 + " " + nbr3);
	}
}