import java.util.*;
import java.lang.*;
import java.io.*;

public class Problem9{

    public static void main(String[] args){
        
        Scanner input = new Scanner(System.in);

        System.out.print("input x1 and y1: ");
        double x1 = input.nextDouble();
        double y1 = input.nextDouble();
		
        System.out.print("input x2 and y2: ");
        double x2 = input.nextdouble();
        double y2 = input.nextDouble();

        double dvalue = Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2);
        double sqrRoot = Math.pow(dvalue, 0.5);

        System.out.printf("The dis between two pnts is %f", sqrRoot);

    }
}