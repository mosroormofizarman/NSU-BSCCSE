import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.*;
public class LoginSystem {

	private JFrame frame;
	private JTextField userLogName;
	private JPasswordField userLogPass;
	private JTextField signUpText;
	private JPasswordField signUpPass;
	private JPasswordField signUpRePass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginSystem window = new LoginSystem();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the application.
	 */
	public LoginSystem() {
		initialize();
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		frame.setBounds(100, 100, 607, 374);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome To Electricity Bill Calculator");
		lblNewLabel.setBackground(Color.DARK_GRAY);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setForeground(Color.YELLOW);
		lblNewLabel.setBounds(111, 11, 382, 37);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("USERNAME");
		lblNewLabel_1.setForeground(Color.YELLOW);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(73, 116, 71, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("PASSWORD");
		lblNewLabel_2.setForeground(Color.YELLOW);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(73, 181, 89, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String userName = userLogName.getText();
				String userPass = userLogPass.getText();
				if(userName.equals("aboni")&&userPass.equals("1713")) {
					JOptionPane.showMessageDialog(frame, "Login Successful.");
					BillCalculation billCalculation = new BillCalculation();
					billCalculation.setVisible(true);
				}
				else {
					userLogName.setText(null);
					userLogPass.setText(null);
					JOptionPane.showMessageDialog(frame, "Invalid Username or Password !");
				}
			}
		});
		btnLogin.setForeground(Color.RED);
		btnLogin.setBackground(Color.DARK_GRAY);
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnLogin.setBounds(151, 254, 89, 23);
		frame.getContentPane().add(btnLogin);
		
		userLogName = new JTextField();
		userLogName.setBounds(73, 141, 167, 27);
		frame.getContentPane().add(userLogName);
		userLogName.setColumns(10);
		
		userLogPass = new JPasswordField();
		userLogPass.setBounds(73, 206, 167, 23);
		frame.getContentPane().add(userLogPass);
		
		JLabel lblNewLabel_3 = new JLabel("NAME");
		lblNewLabel_3.setForeground(Color.YELLOW);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(352, 116, 46, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("PASSWORD");
		lblNewLabel_4.setForeground(Color.YELLOW);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_4.setBounds(352, 177, 86, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		signUpText = new JTextField();
		signUpText.setBounds(351, 143, 151, 23);
		frame.getContentPane().add(signUpText);
		signUpText.setColumns(10);
		
		signUpPass = new JPasswordField();
		signUpPass.setBounds(351, 202, 151, 23);
		frame.getContentPane().add(signUpPass);
		
		JButton btnSignUp = new JButton("SignUp");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String signupName = signUpText.getText();
				String signupPass = signUpPass.getText();
				String signupRePass = signUpRePass.getText();
				if(signupName == "aboni" && signupPass == "1713" && signupRePass == "1713") {
					JOptionPane.showMessageDialog(frame, "Sign Up Successful.");
					BillCalculation billCalculation = new BillCalculation();
					billCalculation.setVisible(true);
				}
				else{
					JOptionPane.showMessageDialog(frame, " Error! ");
				}
			}
		});
		btnSignUp.setForeground(Color.RED);
		btnSignUp.setBackground(Color.DARK_GRAY);
		btnSignUp.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnSignUp.setBounds(417, 290, 89, 23);
		frame.getContentPane().add(btnSignUp);
		
		JLabel lblNewLabel_5 = new JLabel("REPEAT PASSWORD");
		lblNewLabel_5.setForeground(Color.YELLOW);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(351, 236, 151, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		signUpRePass = new JPasswordField();
		signUpRePass.setBounds(351, 256, 151, 23);
		frame.getContentPane().add(signUpRePass);
		
		JLabel lblNewLabel_6 = new JLabel("New User");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_6.setForeground(Color.YELLOW);
		lblNewLabel_6.setBounds(385, 83, 167, 23);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblX = new JLabel("X");
		lblX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.exit(0);
			}
		});
		lblX.setForeground(Color.RED);
		lblX.setBackground(Color.DARK_GRAY);
		lblX.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblX.setBounds(561, 11, 20, 23);
		frame.getContentPane().add(lblX);
		
		JLabel lblAlreadyUser = new JLabel("Already User");
		lblAlreadyUser.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAlreadyUser.setForeground(Color.YELLOW);
		lblAlreadyUser.setBounds(97, 87, 112, 14);
		frame.getContentPane().add(lblAlreadyUser);
	}
}
