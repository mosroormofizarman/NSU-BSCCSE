import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class BillCalculation extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField UnitField;
	private JTextField TimeField;
	private JTextField WattField;
	private JTextField kWhField;
	private JTextField CostperDayField;
	private JTextField totalCostMonthField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BillCalculation frame = new BillCalculation();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BillCalculation() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 664, 364);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Units :");
		lblNewLabel.setBounds(76, 76, 46, 14);
		lblNewLabel.setForeground(Color.YELLOW);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(lblNewLabel);
		
		UnitField = new JTextField();
		UnitField.setBounds(119, 75, 86, 20);
		contentPane.add(UnitField);
		UnitField.setColumns(10);
		
		JLabel lblTime = new JLabel("Time :");
		lblTime.setBounds(76, 117, 46, 14);
		lblTime.setForeground(Color.YELLOW);
		lblTime.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(lblTime);
		
		TimeField = new JTextField();
		TimeField.setBounds(119, 116, 86, 20);
		contentPane.add(TimeField);
		TimeField.setColumns(10);
		
		JLabel lblHour = new JLabel("Hour");
		lblHour.setBounds(215, 119, 46, 14);
		lblHour.setForeground(Color.YELLOW);
		lblHour.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(lblHour);
		
		JLabel lblWatt = new JLabel("Watt :");
		lblWatt.setBounds(76, 158, 46, 14);
		lblWatt.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblWatt.setForeground(Color.YELLOW);
		contentPane.add(lblWatt);
		
		WattField = new JTextField();
		WattField.setBounds(119, 157, 86, 20);
		contentPane.add(WattField);
		WattField.setColumns(10);
		
		JLabel lblW = new JLabel("W");
		lblW.setBounds(215, 158, 46, 14);
		lblW.setForeground(Color.YELLOW);
		lblW.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(lblW);
		
		JLabel lblKwh = new JLabel("kWh :");
		lblKwh.setBounds(76, 202, 46, 14);
		lblKwh.setForeground(Color.YELLOW);
		lblKwh.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(lblKwh);
		
		kWhField = new JTextField();
		kWhField.setBounds(119, 201, 86, 20);
		contentPane.add(kWhField);
		kWhField.setColumns(10);
		
		JLabel lblKwh_1 = new JLabel("Kilo Watt per Hour");
		lblKwh_1.setBounds(215, 202, 122, 19);
		lblKwh_1.setForeground(Color.YELLOW);
		lblKwh_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(lblKwh_1);
		
		JLabel lblCostPerDay = new JLabel("Cost per Day");
		lblCostPerDay.setBounds(356, 85, 99, 20);
		lblCostPerDay.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblCostPerDay.setForeground(Color.YELLOW);
		contentPane.add(lblCostPerDay);
		
		CostperDayField = new JTextField();
		CostperDayField.setBounds(346, 116, 122, 20);
		contentPane.add(CostperDayField);
		CostperDayField.setColumns(10);
		
		JLabel lblCalculationPage = new JLabel("Calculation Page");
		lblCalculationPage.setBounds(221, 11, 188, 35);
		lblCalculationPage.setForeground(Color.YELLOW);
		lblCalculationPage.setFont(new Font("Tahoma", Font.BOLD, 18));
		contentPane.add(lblCalculationPage);
		
		JButton btnConvert = new JButton("Calculate");
		btnConvert.setBounds(116, 246, 89, 23);
		btnConvert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
				int time, watt, unit; 
				double kwh, energy, monthly;
				time = Integer.parseInt(TimeField.getText());
				watt = Integer.parseInt(WattField.getText());
				kwh = (watt * time);
				energy = kwh /1000;
				kWhField.setText(Double.toString(energy));
				unit = Integer.parseInt(UnitField.getText());
				double EnergyPerDay = energy * unit;
				double costPerDay = EnergyPerDay * 3.5;
				CostperDayField.setText(Double.toString(costPerDay));
				monthly = (costPerDay * 30);
				totalCostMonthField.setText(Double.toString(monthly));
			}
				catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Invalid input!");
				}
			}
		});
		btnConvert.setBackground(Color.DARK_GRAY);
		btnConvert.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnConvert.setForeground(Color.RED);
		contentPane.add(btnConvert);
		
		JLabel lblCostPerMonth = new JLabel("Cost per Month");
		lblCostPerMonth.setBounds(356, 150, 109, 31);
		lblCostPerMonth.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblCostPerMonth.setForeground(Color.YELLOW);
		contentPane.add(lblCostPerMonth);
		
		totalCostMonthField = new JTextField();
		totalCostMonthField.setBounds(346, 181, 122, 20);
		contentPane.add(totalCostMonthField);
		totalCostMonthField.setColumns(10);
		
		JLabel lblTk = new JLabel("Tk");
		lblTk.setBounds(471, 117, 46, 14);
		lblTk.setForeground(Color.YELLOW);
		lblTk.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(lblTk);
		
		JLabel lblNewLabel_1 = new JLabel("Tk");
		lblNewLabel_1.setBounds(471, 182, 46, 14);
		lblNewLabel_1.setForeground(Color.YELLOW);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Reset");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				UnitField.setText(null);
				TimeField.setText(null);
				WattField.setText(null);
				kWhField.setText(null);
				CostperDayField.setText(null);
				totalCostMonthField.setText(null);
			}
		});
		btnNewButton.setBackground(Color.DARK_GRAY);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setBounds(248, 246, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblX = new JLabel("X");
		lblX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.exit(0);
			}
		});
		lblX.setForeground(Color.RED);
		lblX.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblX.setBackground(Color.DARK_GRAY);
		lblX.setBounds(622, 11, 16, 14);
		contentPane.add(lblX);
	}
}
