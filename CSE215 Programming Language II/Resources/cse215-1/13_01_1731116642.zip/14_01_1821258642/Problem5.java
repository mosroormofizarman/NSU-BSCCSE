import java.util.*;
import java.lang.*;
import java.io.*;
class Problem5{
public static void main(String[] args){
Scanner input = new Scanner(System.in);
double fahrenheit;
System.out.println(" Enter Temperature in Celsius:");
double celsius=input.nextDouble();
fahrenheit=(9.0/5)*celsius+32;
System.out.print("Temperature in fahrenheit:"+fahrenheit);
}
}