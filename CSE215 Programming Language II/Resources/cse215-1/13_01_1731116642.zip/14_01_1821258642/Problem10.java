import java.util.*;
import java.lang.*;
import java.io.*;
class Problem10{
public static void main(String[] args){
Scanner input=new Scanner(System.in);
System.out.print("Enter distance in miles:");
double distance=input.nextDouble();
System.out.println();
System.out.print("Enter miles per gallon:");
double milespergallon=input.nextDouble();
System.out.println();
System.out.print("Enter price per gallon:");
double pricepergallon=input.nextDouble();
System.out.println();
Double cost;
cost=(distance/milespergallon)*pricepergallon;
System.out.println("cost of the trip is:"+cost);
}
}
