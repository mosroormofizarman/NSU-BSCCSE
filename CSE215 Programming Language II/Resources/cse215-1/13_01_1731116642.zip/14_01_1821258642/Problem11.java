import java.util.*;
import java.lang.*;
import java.io.*;
class Problem11{
public static void main(String[] args){
Scanner input=new Scanner(System.in);
System.out.print("Enter a number between 0 and 1000:");
int num=input.nextInt();
int r;
int q;
int i;
int sum=0;

for (i=1;i<=1000;i++){
r=num%10;
q=num/10;
num=q;
sum=sum+r;
if(q==0){
System.out.println("sum is:"+sum);
break;
}
}
}
}

