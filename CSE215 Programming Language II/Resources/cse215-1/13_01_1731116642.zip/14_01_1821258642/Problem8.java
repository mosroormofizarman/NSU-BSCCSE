import java.util.*;
import java.lang.*;
import java.io.*;
class Problem8{
public static void main(String[] args){
Scanner input = new Scanner(System.in);
System.out.print("Enter your weight in pounds:");
double pounds=input.nextDouble();
System.out.println();
System.out.print("Enter your height in inches:");
double inches=input.nextDouble();
System.out.println();
double kg;
kg=pounds*0.45359237;
double meters;
meters=inches*0.0254;
double BMI;
BMI=kg/(meters*meters);
System.out.println("Your BMI is:"+BMI);
}
}