import java.util.*;
import java.lang.*;
import java.io.*;
class Problem12{
public static void main(String[] args){
Scanner input=new Scanner(System.in);
System.out.print("Enter value of a : ");

int a=input.nextInt();
System.out.println();
System.out.print("Enter value of b : ");
int b=input.nextInt();
System.out.println();
int i;
System.out.print("a");
System.out.print("   ");

System.out.print("b");
System.out.print("   ");

System.out.print("pow(a,b)");
System.out.println();

for(i=1;i<=5;i++){
	
System.out.print(a);
System.out.print("   ");

System.out.print(b);
System.out.print("   ");

System.out.print(Math.pow(a,b));
System.out.println();

a++;
b++;

}
}
}