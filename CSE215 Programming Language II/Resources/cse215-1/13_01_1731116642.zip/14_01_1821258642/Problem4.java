import java.util.*;
import java.lang.*;
import java.io.*;
class Problem4{
public static void main(String[] args){
Scanner input=new Scanner(System.in);
System.out.println("Enter current population:");
double population=input.nextDouble();
double i=31536000;
double birthrate=(double)i/7;
double deathrate=(double)i/13;
double immigrant=(double)i/45;
double increaserate;

increaserate=birthrate-deathrate+immigrant;
int j;


for(j=1;j<=5;j++){
	
population=population+increaserate;
System.out.println("population of year"+j+":"+(int)population);
}
}
}


