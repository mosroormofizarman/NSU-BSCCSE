import java.util.*;
import java.lang.*;
import java.io.*;
class Problem7{
public static void main(String[] args){
Scanner input=new Scanner(System.in);
System.out.print("Enter minutes:");
double mins=input.nextDouble();
System.out.println();
double i=1440.0;
double d=mins/i;
double years=d/365.0;
int y=(int)years;
double days;
days=d-(y*365);
System.out.println(" Years:"+y);
System.out.println(" Days:"+(int)days);

}
}


