import java.util.*;
import java.lang.*;
import java.io.*;
class Problem14{
public static void main(String[] args){
Scanner input=new Scanner(System.in);
int num1 = (int)(Math.random() * 10);
int num2 = (int)(Math.random() *10);
int num3 = (int)(Math.random() *10);
System.out.print("Sum of"+num1+"+"+num2+"+"+num3+"is :");
int ans=input.nextInt();
System.out.println();
int sum;
sum=num1+num2+num3;
if(sum==ans){
System.out.println("Your answer is right");
}
else{
System.out.println("Your answer is wrong");
}
}
}
