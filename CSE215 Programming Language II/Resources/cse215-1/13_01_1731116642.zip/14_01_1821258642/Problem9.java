import java.util.*;
import java.lang.*;
import java.io.*;
class Problem9{
public static void main(String[] args){
Scanner input=new Scanner(System.in);
System.out.print("Enter value x1:");
double x1=input.nextDouble();
System.out.println();
System.out.print("Enter value x2:");
double x2=input.nextDouble();
System.out.println();
System.out.print("Enter value y1:");
double y1=input.nextDouble();
System.out.println();
System.out.print("Enter value y2:");
double y2=input.nextDouble();
System.out.println();
double x;
double y;
double z;
double distance ;
x=Math.pow(x2-x1,2);
y=Math.pow(y2-y1,2);
z=x+y;
distance= Math.pow(z,.5);
System.out.println("Distance:"+distance);
}
}
