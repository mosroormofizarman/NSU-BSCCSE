import java.util.*;
import java.lang.*;
import java.io.*;
class Problem2{
public static void main(String [] args ){
double radius=5.5;
double perimeter;
double area;
perimeter=2*radius*3.14;
System.out.println("The perimeter is :"+perimeter);
area=radius*radius*3.14;
System.out.println("The area is :"+area);
}

}
