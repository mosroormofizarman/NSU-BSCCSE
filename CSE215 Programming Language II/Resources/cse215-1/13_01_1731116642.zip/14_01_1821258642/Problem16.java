import java.util.*;
import java.lang.*;
import java.io.*;
class Problem16{
public static void main(String[] args){
Scanner input=new Scanner(System.in);
System.out.print("Enter today's day:");
int day=input.nextInt();
System.out.println();
System.out.print("Enter the number of days elapsed since today:");
int elapsedDay=input.nextInt();
switch(day){
case 0:
System.out.println("Today is sunday");
break;
case 1:
System.out.println("Today is monday");
break;
case 2:
System.out.println("Today is tuesday");
break;
case 3:
System.out.println("Today is wednesday");
break;
case 4:
System.out.println("Today is thursday");
break;
case 5:
System.out.println("Today is friday");
break;
case 6:
System.out.println("Today is saturday");
break;
}
int futureday;
futureday=(day+elapsedDay)%7;
switch(futureday){
case 0:
System.out.println("future day is sunday");
break;
case 1:
System.out.println("future day is monday");
break;
case 2:
System.out.println("future day is tuesday");
break;
case 3:
System.out.println("future day is wednesday");
break;
case 4:
System.out.println("future day is thursday");
break;
case 5:
System.out.println("future day is friday");
break;
case 6:
System.out.println("future day is saturday");
}
}
}

