import java.util.*;
import java.lang.*;
import java.io.*;
class Problem15{
public static void main(String[] args){
Scanner input=new Scanner(System.in);
System.out.print("Enter first number :");
double num1=input.nextDouble();
System.out.println();
System.out.print("Enter second number :");
double num2=input.nextDouble();
System.out.println();
System.out.print("Enter third number :");
double num3=input.nextDouble();
System.out.println();
if(num1>num2 && num2>num3){
System.out.println(num3+"<"+num2+"<"+num1);
}
else if(num1>num2 && num3>num2){
System.out.println(num2+"<"+num3+"<"+num1);
}
else if(num2>num1 && num1>num3){
System.out.println(num3+"<"+num1+"<"+num2);
}
else if(num2>num1 && num3>num1){
System.out.println(num1+"<"+num3+"<"+num2);
}
else if(num3>num1 && num1>num2){
System.out.println(num2+"<"+num1+"<"+num3);
}
else if(num3>num1 && num2>num1){
System.out.println(num1+"<"+num2+"<"+num3);
}
else{
System.out.println("you entered equal numbers");
}
}
}

