import java.util.*;
import java.lang.*;
import java.io.*;
class Problem17{
public static void main(String[] args){
Scanner input= new Scanner(System.in);
System.out.print("Enter a three digit number:");
int num=input.nextInt();
System.out.println();
int temp;
temp=num;
int r;
int i;
int sum;
sum=0;
for(i=1;i<=1000;i++){
	r=temp%10;
	temp=temp/10;
	sum=sum*10+r;
	if(temp==0){
		if(sum==num){
			System.out.println("Entered number is a palindrome");
		}
	else{
		System.out.println("Entered number is not a palindrome");
	}
	break;
	}
}
}
}

