import java.util.*;
import java.lang.*;
import java.io.*;
class Problem3{
public static void main(String [] args ){
	Scanner input=new Scanner(System.in);
	
	System.out.print("Enter distance in Kilometers:");
	double km=input.nextDouble();
	
	System.out.print("Enter minutes:");
	int min=input.nextInt();
	
	System.out.print("Enter seconds:");
	int sec=input.nextInt();
	
	int m,s;
	double hour;
	double mile;
	double avr_speed;
	m=min*60;
	s=m+sec;
	hour=(double)s/3600;
	mile=km/1.6;
	avr_speed=mile/hour;
	System.out.print("Average speed in mph:"+avr_speed);
	
	
	
	
}


}
