import java.util.*;
import java.lang.*;
import java.io.*;
class Problem6{
public static void main(String[] args){
Scanner input=new Scanner(System.in);
System.out.print("Enter subtotal:");
double subtotal=input.nextDouble();
System.out.println();
System.out.print("Enter gratuity rate:");
double gratuityrate=input.nextDouble();
System.out.println();
double gratuity;
gratuity=(double)gratuityrate/subtotal;
System.out.println("Gratuity:"+gratuity);
double total;
total=subtotal+gratuity;
System.out.println("Total:"+total);
}
}
