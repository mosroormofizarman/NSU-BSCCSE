import java.util.*;
import java.lang.*;
import java.io.*;
class Problem13{
public static void main(String[] args){
Scanner input=new Scanner(System.in);
System.out.print("Enter investment amount:");
double pv=input.nextDouble();
System.out.println();
System.out.print("Enter annual interest rate in percentage:");
double i=input.nextDouble();
System.out.println();
System.out.print("Enter number of years:");
double y=input.nextDouble();
System.out.println();
double x;
x=i/100;
double fv;
fv=pv*Math.pow(1+(x/12),y*12);
System.out.print("Future investment value:"+fv);

}
}